package com.csmtech.copilot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CopilotDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

/**
 * 
 */
package com.csmtech.copilot;

import lombok.Data;

/**
 * 
 */

@Data
public class copilotBean {

	private String applicantName;
    private String fatherName;
    private String motherName;
    private String district;
    private String block;
    private String post;
    private String policeStation;
    private String village;
    private String address;
    private String dob;
    private String gender;
    private String caste;
    private String education;
    private String mobile;
    private String email;
    private String criminal;
    private String caseNumber;
    private String freedom;
    private String idMark1;
    private String idMark2;
}
